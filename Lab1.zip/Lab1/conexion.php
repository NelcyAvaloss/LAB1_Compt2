<?php

$conexion = mysqli_connect("localhost", "root","","Escuela");
if(mysqli_connect_errno()){
die("Error". mysqli_connect_error());
}
?>