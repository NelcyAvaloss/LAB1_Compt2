<footer>
    <h1>Aqui va el footer</h1>
</footer>