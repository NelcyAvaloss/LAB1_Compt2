<?php include 'conexion.php';

    $id = $_GET['id'];
    $resultado= $conexion->query("SELECT *FROM 
    tbl_estudiantes WHERE id=$id");
    $estudiantes = $resultado->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
        <label for="">Nombre</label>
        <input type="text" name="nombre" id="" 
        value="<?php echo $estudiantes['nombre']?>">
        <label for="">Carnet</label>
        <input type="text" name="carnet" id=""
        value="<?php echo $estudiantes['carnet']?>">
        <label for="">Materia</label>
        <input type="text" name="materia" id=""
        value="<?php echo $estudiantes['materia']?>">
        <button type="submit">Actualizar Registro</button>
        <a href="index.php"><button type="button">Cancelar</button></a>
    </form>

    <?php
        if($_SERVER['REQUEST_METHOD']=="POST"){
            $nom = $_POST['nombre'];
            $ct = $_POST['carnet'];
            $mat = $_POST['materia'];

            $insercion = $conexion
            ->prepare("UPDATE tbl_estudiantes SET
            nombre=?,carnet=?,materia=? WHERE id=$id");
            $insercion->bind_param("sss", $nom, $ct, $mat);
            $insercion->execute();
            header("Location:index.php");

        }

    ?>

</body>

</html>

